package com.example.mypolinoms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

public class AddFunctionActivity extends AppCompatActivity {
    EditText Degree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_function);
        Degree = findViewById(R.id())

    }
}